#include "Header.h"

int main()
{
    menu game; // creates menu object

    game.welcome(); // starts game for object

    return 0;
}
